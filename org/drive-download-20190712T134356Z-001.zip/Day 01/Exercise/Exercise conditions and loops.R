#######################################
#                                     #
#         Exercise R1 - 5             #
#                                     #
#######################################


# 1. If-else
#Calculate BMI from weight and height and print the condition

weight <-    #Input your weight in kg
height <-    #Input your height in m
  
BMI    <- weight/(height)^2

if(BMI ){
  
  print(" ")
  
}else if(){
  
  print(" ")
  
}else{
  
  print(" ")
  
}


# 2. For Loop - use for loop to calculate BMI of 5 persons and store it in BMIvector

weight2   <- c(45, 55, 65, 75, 85)
height2   <- c(1.60, 1.63, 1.70, 1.50, 1.40)
BMIvector <- double()

for(i in ){
  
  BMIvector[i] <-
    
}

print(BMIvector)
