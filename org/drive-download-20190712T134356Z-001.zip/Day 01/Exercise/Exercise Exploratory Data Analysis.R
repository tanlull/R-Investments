#######################################
#                                     #
#         Exercise R1 - 2             #
#                                     #
#######################################

# Exploratory data analysis

### 1. Load 'airquality' dataset

data(airquality)

### 2. Explore structure of an 'airquality' dataset.

s--(a---------)

### 3. Get the minimum, maximum, and number of missing values in the dataset

s------(a---------)

### 4. Print the first 4 rows and the last 5 rows of the dataset

print(h---(airquality, n = -))

print(t---(airquality, n = -))