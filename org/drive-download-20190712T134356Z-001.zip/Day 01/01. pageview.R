library(pageviews)
pagestat <- article_pageviews(project = "en.wikipedia", 
                              article = "Emma_Watson", platform = "all", user_type = "all",
                              start = "2017010100", end = "2018012400")

plot(pagestat$date, pagestat$views, type = "l")
