#############################################
#                                           #
#           Capstone Project                #
#                                           #
#############################################

### Load relevant libraries



### 1. Get historical data of CPALL from 01-Jan-2015 to 31-Dec-2018 from Yahoo Finance. Name it as 'cpall'

cpall     <- 
print  


### 2. Subset adjusted close price from cpall dataset and name it as 'price'
  
price <-
print  
  
### 3. Calculate daily returns from adjusted close price and name it as 'returns'. Use log return for calculation.
  
returns   <-
print
    
### 4. Calculate mean, sd, and SharpeRatio of daily returns
  
mean.ret  <-
print  

sd.ret    <-
print

sharpe    <-
print
    
### 5. Technical indicator: Calculate Bollinger Bands and RSI with default parameters.

price$bband <-
  
price$rsi   <-

print  

### 6. Plot price with Bollinger Bands and RSI in one plot
  

  
### 7. Plot performance summary with cumulative returns, daily returns, and drawdown in one plot
  
  
### 8. Show top 10 drawdowns as a table
  
  
  