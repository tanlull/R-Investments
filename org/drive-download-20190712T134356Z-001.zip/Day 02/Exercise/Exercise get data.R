#############################################
#                                           #
#          Exercise Get Data                #
#                                           #
#############################################


# 1. Load package require for getting financial data from Yahoo finance

library(q-------)


# 2. Get 'CPALL' historical data from Yahoo finance use R function (from 1 Jan 2013 to 31 Dec 2015)

data <- g---------(Symbols = '--------', scr = 'y----', 
                   auto.assign = FALSE, warnings = FALSE, from = " ", to = " ")

# 3. Show first 3 rows of data
h---(d---, n = -)

# 4. Show last 3 rows of data
t---(----, n = -)